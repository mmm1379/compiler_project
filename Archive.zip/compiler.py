from parser import parseNextToken

while not parseNextToken():pass
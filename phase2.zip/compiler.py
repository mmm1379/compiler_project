# read from input.txt
# Mohammad Mahdi Masoudpour-98102335
# Sajad Paksima-98106286

from parser import parseNextToken

while not parseNextToken():pass